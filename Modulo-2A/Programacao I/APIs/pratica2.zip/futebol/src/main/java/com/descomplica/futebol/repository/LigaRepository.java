package com.descomplica.futebol.repository;

import com.descomplica.futebol.entity.Liga;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LigaRepository extends JpaRepository<Liga, Integer> {
}
