package com.descomplica.futebol.repository;

import com.descomplica.futebol.entity.Pais;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaisRepository extends JpaRepository<Pais, Integer> {
}
